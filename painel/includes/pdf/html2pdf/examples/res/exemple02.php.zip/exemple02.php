<?

	 if($_SERVER['REMOTE_ADDR'] == '::1'){
        $host = 'localhost';		//servidor
        $user = 'root';				//usuario
        $senha = 'qweasd';				//senha
        $banco = 'vereda'; 
    }else{
       
    }
		
		
 		$conn = mysqli_connect($host, $user, $senha, $banco) or die(mysqli_error());
			mysqli_query($conn,"set names 'utf8'");
		mysqli_query($conn,"SET NAMES 'utf8'");
		mysqli_query($conn,'SET character_set_connection=utf8');
		mysqli_query($conn,'SET character_set_client=utf8');
		mysqli_query($conn,'SET character_set_results=utf8');
		
 		
		
		$sql = "SELECT * from `etiquetas`";
$query = mysqli_query($conn,$sql);

		
		
	 
 

 	?>
  
        
<page backtop="15mm" backbottom="0mm" backleft="6mm" backright="6mm" style="font-size: 12pt">
	<table cellpadding="0" cellspacing="0" border="0" style="margin:0">
	<tr>
	<?
		$i = 0;
		$count = 0;
		foreach($query as $lis){
			
			
			if($lis['pp'] > 0){
				while($count < $lis['pp']){
					if($i == '6'){
						$i = 1;
						echo '</tr><tr>';
					}else{
						$i++;
					}
	?>
	
		<td style="width:31.4mm; height:71mm; margin:0px;padding:0; text-align:left; vertical-align: top;">
			<table cellpadding="0" cellspacing="0" border="0" style="margin:0; height:71mm; ">
				<tr style="text-align:center">
					<td style="padding-bottom:2px; padding-top:30px">
						<h5 style="font-size:16px;font-family:hurmegeometricsans4; margin:20px 0 0; width:31.4mm;">VEREDA</h5>
						<h6 style="margin:0 0px; font-size:7px;width:31.4mm;">Confecção e Comércio de Roupas</h6>
						<h6 style="font-size:7px;width:31.4mm; margin:5px 0 0; padding:0; line-height:7px; display:block">CNPJ</h6>
						<strong style=" margin:0;font-size:9px;line-height:8px; width:31.4mm; padding:0; display:block">26.868.826/0001-60</strong>
					</td>
				</tr>
				<tr style=" text-align:center">
					<td style="border-top:1px solid #444;padding-top:2px; width:31.4mm; height:85px">
						<table cellpadding="0" cellspacing="0" border="0" style="margin:0;width:31.4mm;">
					<? if($lis['poliester'] > 0){?><tr><td style="width:31.4mm;"><strong style="text-transform: uppercase; font-size:10px;font-family:hurmegeometricsans4; line-height:10px"><?=$lis['poliester']?>% Poliester</strong></td></tr><?}
						if($lis['elastano'] > 0){?><tr><td style="width:31.4mm;"><strong style="text-transform: uppercase; font-size:10px;font-family:hurmegeometricsans4; line-height:10px "><?=$lis['elastano']?>% Elastano</strong></td></tr><?}
						if($lis['algodao'] > 0){?><tr><td style="width:31.4mm;"><strong style="text-transform: uppercase; font-size:10px;font-family:hurmegeometricsans4; line-height:10px"><?=$lis['algodao']?>% ALGODÃO</strong></td></tr><?}
						if($lis['poliamida'] > 0){?><tr><td style="width:31.4mm;"><strong style="text-transform: uppercase; font-size:10px;font-family:hurmegeometricsans4; line-height:10px"><?=$lis['poliamida']?>% Poliamida</strong></td></tr><?}
						if($lis['linho'] > 0){?><tr><td style="width:31.4mm;"><strong style="text-transform: uppercase; font-size:10px;font-family:hurmegeometricsans4; line-height:10px"><?=$lis['linho']?>% Linho</strong></td></tr><?}
						if($lis['viscose'] > 0){?><tr><td style="width:31.4mm;"><strong style="text-transform: uppercase; font-size:10px;font-family:hurmegeometricsans4; line-height:10px"><?=$lis['viscose']?>% Viscose</strong></td></tr><?}
						if($lis['poliuretano'] > 0){?><tr><td style="width:31.4mm;"><strong style="text-transform: uppercase; font-size:10px;font-family:hurmegeometricsans4; line-height:10px"><?=$lis['poliuretano']?>% Poliuretano</strong></td></tr><?}
						if($lis['acrilico'] > 0){?><tr><td style="width:31.4mm;"><strong style="text-transform: uppercase; font-size:10px;font-family:hurmegeometricsans4; line-height:10px"><?=$lis['acrilico']?>% ACRÍLICO</strong></td></tr><?}?>
						</table>
					<table cellpadding="0" cellspacing="0" border="0" style="margin:5px 0 0;width:31.4mm;">
						<tr>
							<td style="width:31.4mm;text-align:center; height:17px">
						<?
						$ic = explode(',',$lis['icon']);
						$a = 0;
						foreach($ic as $icons){
							if($a == '3'){
								$a = 0;
								echo '</td></tr><tr><td style="width:31.4mm; height:17px;text-align:center;padding-top:3px">';
							}else{
								$a++;
							}
							echo '<img src="http://vereda.server.com:8888/painel/images/icons/jpeg/'.$icons.'.jpg" style="width:30px;max-height:12px; margin:0px 2px 0; float:left" />';
						}
						?>
						</td>
						</tr>
						
					</table>
					</td>
				</tr>
				<tr style="text-align:center">
					<td>
						<h4 style="font-size:45px;font-family:hurmegeometricsans4; margin:0">PP</h4>
						<strong style="text-transform: uppercase; font-size:7px; margin:2px 0 0; display: inline-block">Feito no Rio Grande do Sul</strong>
					</td>
				</tr>
			</table>
		</td>
		<?
					$count++;
		}
				}
		if($lis['p'] > 0){
			$count = 0;
			while($count < $lis['p']){
					if($i == '6'){
						$i = 1;
						echo '</tr><tr>';
					}else{
						$i++;
					}
	?>
	
		<td style="width:31.4mm; height:70mm; margin:0px;padding:0; text-align:left; vertical-align: top;">
			<table cellpadding="0" cellspacing="0" border="0" style="margin:0; height:70mm; ">
				<tr style="text-align:center">
					<td style="padding-bottom:2px; padding-top:30px">
						<h5 style="font-size:16px;font-family:hurmegeometricsans4; margin:20px 0 0; width:31.4mm;">VEREDA</h5>
						<h6 style="margin:0 0px; font-size:7px;width:31.4mm;">Confecção e Comércio de Roupas</h6>
						<h6 style="font-size:7px;width:31.4mm; margin:5px 0 0; padding:0; line-height:7px; display:block">CNPJ</h6>
						<strong style=" margin:0;font-size:9px;line-height:8px; width:31.4mm; padding:0; display:block">26.868.826/0001-60</strong>
					</td>
				</tr>
				<tr style=" text-align:center">
					<td style="border-top:1px solid #444;padding-top:2px; width:31.4mm; height:85px">
						<table cellpadding="0" cellspacing="0" border="0" style="margin:0;width:31.4mm;">
					<? if($lis['poliester'] > 0){?><tr><td style="width:31.4mm;"><strong style="text-transform: uppercase; font-size:10px;font-family:hurmegeometricsans4; line-height:10px"><?=$lis['poliester']?>% Poliester</strong></td></tr><?}
						if($lis['elastano'] > 0){?><tr><td style="width:31.4mm;"><strong style="text-transform: uppercase; font-size:10px;font-family:hurmegeometricsans4; line-height:10px "><?=$lis['elastano']?>% Elastano</strong></td></tr><?}
						if($lis['algodao'] > 0){?><tr><td style="width:31.4mm;"><strong style="text-transform: uppercase; font-size:10px;font-family:hurmegeometricsans4; line-height:10px"><?=$lis['algodao']?>% ALGODÃO</strong></td></tr><?}
						if($lis['poliamida'] > 0){?><tr><td style="width:31.4mm;"><strong style="text-transform: uppercase; font-size:10px;font-family:hurmegeometricsans4; line-height:10px"><?=$lis['poliamida']?>% Poliamida</strong></td></tr><?}
						if($lis['linho'] > 0){?><tr><td style="width:31.4mm;"><strong style="text-transform: uppercase; font-size:10px;font-family:hurmegeometricsans4; line-height:10px"><?=$lis['linho']?>% Linho</strong></td></tr><?}
						if($lis['viscose'] > 0){?><tr><td style="width:31.4mm;"><strong style="text-transform: uppercase; font-size:10px;font-family:hurmegeometricsans4; line-height:10px"><?=$lis['viscose']?>% Viscose</strong></td></tr><?}
						if($lis['poliuretano'] > 0){?><tr><td style="width:31.4mm;"><strong style="text-transform: uppercase; font-size:10px;font-family:hurmegeometricsans4; line-height:10px"><?=$lis['poliuretano']?>% Poliuretano</strong></td></tr><?}
						if($lis['acrilico'] > 0){?><tr><td style="width:31.4mm;"><strong style="text-transform: uppercase; font-size:10px;font-family:hurmegeometricsans4; line-height:10px"><?=$lis['acrilico']?>% ACRÍLICO</strong></td></tr><?}?>
						</table>
					<table cellpadding="0" cellspacing="0" border="0" style="margin:5px 0 0;width:31.4mm;">
						<tr>
							<td style="width:31.4mm;text-align:center; height:17px">
						<?
						$ic = explode(',',$lis['icon']);
						$a = 0;
						foreach($ic as $icons){
							if($a == '3'){
								$a = 0;
								echo '</td></tr><tr><td style="width:31.4mm; height:17px;text-align:center;padding-top:3px">';
							}else{
								$a++;
							}
							echo '<img src="http://vereda.server.com:8888/painel/images/icons/jpeg/'.$icons.'.jpg" style="width:30px;max-height:12px; margin:0px 2px 0; float:left" />';
						}
						?>
						</td>
						</tr>
						
					</table>
					</td>
				</tr>
				<tr style="text-align:center">
					<td>
						<h4 style="font-size:45px;font-family:hurmegeometricsans4; margin:0">P</h4>
						<strong style="text-transform: uppercase; font-size:7px; margin:2px 0 0; display: inline-block">Feito no Rio Grande do Sul</strong>
					</td>
				</tr>
			</table>
		</td>
		<?
				$count++;
		}
		}
			
			if($lis['m'] > 0){
				$count = 0;
				while($count < $lis['m']){
					if($i == '6'){
						$i = 1;
						echo '</tr><tr>';
					}else{
						$i++;
					}
				
	?>
	
		<td style="width:31.4mm; height:70mm; margin:0px;padding:0; text-align:left; vertical-align: top;">
			<table cellpadding="0" cellspacing="0" border="0" style="margin:0; height:70mm; ">
				<tr style="text-align:center">
					<td style="padding-bottom:2px; padding-top:30px">
						<h5 style="font-size:16px;font-family:hurmegeometricsans4; margin:20px 0 0; width:31.4mm;">VEREDA</h5>
						<h6 style="margin:0 0px; font-size:7px;width:31.4mm;">Confecção e Comércio de Roupas</h6>
						<h6 style="font-size:7px;width:31.4mm; margin:5px 0 0; padding:0; line-height:7px; display:block">CNPJ</h6>
						<strong style=" margin:0;font-size:9px;line-height:8px; width:31.4mm; padding:0; display:block">26.868.826/0001-60</strong>
					</td>
				</tr>
				<tr style=" text-align:center">
					<td style="border-top:1px solid #444;padding-top:2px; width:31.4mm; height:85px">
						<table cellpadding="0" cellspacing="0" border="0" style="margin:0;width:31.4mm;">
					<? if($lis['poliester'] > 0){?><tr><td style="width:31.4mm;"><strong style="text-transform: uppercase; font-size:10px;font-family:hurmegeometricsans4; line-height:10px"><?=$lis['poliester']?>% Poliester</strong></td></tr><?}
						if($lis['elastano'] > 0){?><tr><td style="width:31.4mm;"><strong style="text-transform: uppercase; font-size:10px;font-family:hurmegeometricsans4; line-height:10px "><?=$lis['elastano']?>% Elastano</strong></td></tr><?}
						if($lis['algodao'] > 0){?><tr><td style="width:31.4mm;"><strong style="text-transform: uppercase; font-size:10px;font-family:hurmegeometricsans4; line-height:10px"><?=$lis['algodao']?>% ALGODÃO</strong></td></tr><?}
						if($lis['poliamida'] > 0){?><tr><td style="width:31.4mm;"><strong style="text-transform: uppercase; font-size:10px;font-family:hurmegeometricsans4; line-height:10px"><?=$lis['poliamida']?>% Poliamida</strong></td></tr><?}
						if($lis['linho'] > 0){?><tr><td style="width:31.4mm;"><strong style="text-transform: uppercase; font-size:10px;font-family:hurmegeometricsans4; line-height:10px"><?=$lis['linho']?>% Linho</strong></td></tr><?}
						if($lis['viscose'] > 0){?><tr><td style="width:31.4mm;"><strong style="text-transform: uppercase; font-size:10px;font-family:hurmegeometricsans4; line-height:10px"><?=$lis['viscose']?>% Viscose</strong></td></tr><?}
						if($lis['poliuretano'] > 0){?><tr><td style="width:31.4mm;"><strong style="text-transform: uppercase; font-size:10px;font-family:hurmegeometricsans4; line-height:10px"><?=$lis['poliuretano']?>% Poliuretano</strong></td></tr><?}
						if($lis['acrilico'] > 0){?><tr><td style="width:31.4mm;"><strong style="text-transform: uppercase; font-size:10px;font-family:hurmegeometricsans4; line-height:10px"><?=$lis['acrilico']?>% ACRÍLICO</strong></td></tr><?}?>
						</table>
					<table cellpadding="0" cellspacing="0" border="0" style="margin:5px 0 0;width:31.4mm;">
						<tr>
							<td style="width:31.4mm;text-align:center; height:17px">
						<?
						$ic = explode(',',$lis['icon']);
						$a = 0;
						foreach($ic as $icons){
							if($a == '3'){
								$a = 0;
								echo '</td></tr><tr><td style="width:31.4mm; height:17px;text-align:center;padding-top:3px">';
							}else{
								$a++;
							}
							echo '<img src="http://vereda.server.com:8888/painel/images/icons/jpeg/'.$icons.'.jpg" style="width:30px;max-height:12px; margin:0px 2px 0; float:left" />';
						}
						?>
						</td>
						</tr>
						
					</table>
					</td>
				</tr>
				<tr style="text-align:center">
					<td>
						<h4 style="font-size:45px;font-family:hurmegeometricsans4; margin:0">M</h4>
						<strong style="text-transform: uppercase; font-size:7px; margin:2px 0 0; display: inline-block">Feito no Rio Grande do Sul</strong>
					</td>
				</tr>
			</table>
		</td>
		<?
					$count++;
		}
		}
		
			
		if($lis['g'] > 0){
			$count = 0;
				while($count < $lis['g']){
					if($i == '6'){
						$i = 1;
						echo '</tr><tr>';
					}else{
						$i++;
					}
	?>
	
		<td style="width:31.4mm; height:70mm; margin:0px;padding:0; text-align:left; vertical-align: top;">
			<table cellpadding="0" cellspacing="0" border="0" style="margin:0; height:70mm; ">
				<tr style="text-align:center">
					<td style="padding-bottom:2px; padding-top:30px">
						<h5 style="font-size:16px;font-family:hurmegeometricsans4; margin:20px 0 0; width:31.4mm;">VEREDA</h5>
						<h6 style="margin:0 0px; font-size:7px;width:31.4mm;">Confecção e Comércio de Roupas</h6>
						<h6 style="font-size:7px;width:31.4mm; margin:5px 0 0; padding:0; line-height:7px; display:block">CNPJ</h6>
						<strong style=" margin:0;font-size:9px;line-height:8px; width:31.4mm; padding:0; display:block">26.868.826/0001-60</strong>
					</td>
				</tr>
				<tr style=" text-align:center">
					<td style="border-top:1px solid #444;padding-top:2px; width:31.4mm; height:85px">
						<table cellpadding="0" cellspacing="0" border="0" style="margin:0;width:31.4mm;">
					<? if($lis['poliester'] > 0){?><tr><td style="width:31.4mm;"><strong style="text-transform: uppercase; font-size:10px;font-family:hurmegeometricsans4; line-height:10px"><?=$lis['poliester']?>% Poliester</strong></td></tr><?}
						if($lis['elastano'] > 0){?><tr><td style="width:31.4mm;"><strong style="text-transform: uppercase; font-size:10px;font-family:hurmegeometricsans4; line-height:10px "><?=$lis['elastano']?>% Elastano</strong></td></tr><?}
						if($lis['algodao'] > 0){?><tr><td style="width:31.4mm;"><strong style="text-transform: uppercase; font-size:10px;font-family:hurmegeometricsans4; line-height:10px"><?=$lis['algodao']?>% ALGODÃO</strong></td></tr><?}
						if($lis['poliamida'] > 0){?><tr><td style="width:31.4mm;"><strong style="text-transform: uppercase; font-size:10px;font-family:hurmegeometricsans4; line-height:10px"><?=$lis['poliamida']?>% Poliamida</strong></td></tr><?}
						if($lis['linho'] > 0){?><tr><td style="width:31.4mm;"><strong style="text-transform: uppercase; font-size:10px;font-family:hurmegeometricsans4; line-height:10px"><?=$lis['linho']?>% Linho</strong></td></tr><?}
						if($lis['viscose'] > 0){?><tr><td style="width:31.4mm;"><strong style="text-transform: uppercase; font-size:10px;font-family:hurmegeometricsans4; line-height:10px"><?=$lis['viscose']?>% Viscose</strong></td></tr><?}
						if($lis['poliuretano'] > 0){?><tr><td style="width:31.4mm;"><strong style="text-transform: uppercase; font-size:10px;font-family:hurmegeometricsans4; line-height:10px"><?=$lis['poliuretano']?>% Poliuretano</strong></td></tr><?}
						if($lis['acrilico'] > 0){?><tr><td style="width:31.4mm;"><strong style="text-transform: uppercase; font-size:10px;font-family:hurmegeometricsans4; line-height:10px"><?=$lis['acrilico']?>% ACRÍLICO</strong></td></tr><?}?>
						</table>
					<table cellpadding="0" cellspacing="0" border="0" style="margin:5px 0 0;width:31.4mm;">
						<tr>
							<td style="width:31.4mm;text-align:center; height:17px">
						<?
						$ic = explode(',',$lis['icon']);
						$a = 0;
						foreach($ic as $icons){
							if($a == '3'){
								$a = 0;
								echo '</td></tr><tr><td style="width:31.4mm; height:17px;text-align:center;padding-top:3px">';
							}else{
								$a++;
							}
							echo '<img src="http://vereda.server.com:8888/painel/images/icons/JPEG/'.$icons.'.jpg" style="width:30px;max-height:12px; margin:0px 2px 0; float:left" />';
						}
						?>
						</td>
						</tr>
						
					</table>
					</td>
				</tr>
				<tr style="text-align:center">
					<td>
						<h4 style="font-size:45px;font-family:hurmegeometricsans4; margin:0">G</h4>
						<strong style="text-transform: uppercase; font-size:7px; margin:2px 0 0; display: inline-block">Feito no Rio Grande do Sul</strong>
					</td>
				</tr>
			</table>
		</td>
		<?
					$count++;
		}
		}
			
			
		if($lis['u'] > 0){
			$count = 0;
				while($count < $lis['u']){
					if($i == '6'){
						$i = 1;
						echo '</tr><tr>';
					}else{
						$i++;
					}
	?>
	
		<td style="width:31.4mm; height:70mm; margin:0px;padding:0; text-align:left; vertical-align: top">
			<table cellpadding="0" cellspacing="0" border="0" style="margin:0; height:70mm; ">
				<tr style="text-align:center">
					<td style="padding-bottom:2px; padding-top:30px">
						<h5 style="font-size:16px;font-family:hurmegeometricsans4; margin:20px 0 0; width:31.4mm;">VEREDA</h5>
						<h6 style="margin:0 0px; font-size:7px;width:31.4mm;">Confecção e Comércio de Roupas</h6>
						<h6 style="font-size:7px;width:31.4mm; margin:5px 0 0; padding:0; line-height:7px; display:block">CNPJ</h6>
						<strong style=" margin:0;font-size:9px;line-height:8px; width:31.4mm; padding:0; display:block">26.868.826/0001-60</strong>
					</td>
				</tr>
				<tr style=" text-align:center">
					<td style="border-top:1px solid #444;padding-top:2px; width:31.4mm; height:85px">
						<table cellpadding="0" cellspacing="0" border="0" style="margin:0;width:31.4mm;">
					<? if($lis['poliester'] > 0){?><tr><td style="width:31.4mm;"><strong style="text-transform: uppercase; font-size:10px;font-family:hurmegeometricsans4; line-height:10px"><?=$lis['poliester']?>% Poliester</strong></td></tr><?}
						if($lis['elastano'] > 0){?><tr><td style="width:31.4mm;"><strong style="text-transform: uppercase; font-size:10px;font-family:hurmegeometricsans4; line-height:10px "><?=$lis['elastano']?>% Elastano</strong></td></tr><?}
						if($lis['algodao'] > 0){?><tr><td style="width:31.4mm;"><strong style="text-transform: uppercase; font-size:10px;font-family:hurmegeometricsans4; line-height:10px"><?=$lis['algodao']?>% ALGODÃO</strong></td></tr><?}
						if($lis['poliamida'] > 0){?><tr><td style="width:31.4mm;"><strong style="text-transform: uppercase; font-size:10px;font-family:hurmegeometricsans4; line-height:10px"><?=$lis['poliamida']?>% Poliamida</strong></td></tr><?}
						if($lis['linho'] > 0){?><tr><td style="width:31.4mm;"><strong style="text-transform: uppercase; font-size:10px;font-family:hurmegeometricsans4; line-height:10px"><?=$lis['linho']?>% Linho</strong></td></tr><?}
						if($lis['viscose'] > 0){?><tr><td style="width:31.4mm;"><strong style="text-transform: uppercase; font-size:10px;font-family:hurmegeometricsans4; line-height:10px"><?=$lis['viscose']?>% Viscose</strong></td></tr><?}
						if($lis['poliuretano'] > 0){?><tr><td style="width:31.4mm;"><strong style="text-transform: uppercase; font-size:10px;font-family:hurmegeometricsans4; line-height:10px"><?=$lis['poliuretano']?>% Poliuretano</strong></td></tr><?}
						if($lis['acrilico'] > 0){?><tr><td style="width:31.4mm;"><strong style="text-transform: uppercase; font-size:10px;font-family:hurmegeometricsans4; line-height:10px"><?=$lis['acrilico']?>% ACRÍLICO</strong></td></tr><?}?>
						</table>
					<table cellpadding="0" cellspacing="0" border="0" style="margin:5px 0 0;width:31.4mm;">
						<tr>
							<td style="width:31.4mm;text-align:center; height:17px">
						<?
						$ic = explode(',',$lis['icon']);
						$a = 0;
						foreach($ic as $icons){
							if($a == '3'){
								$a = 0;
								echo '</td></tr><tr><td style="width:31.4mm; height:17px;text-align:center;padding-top:3px">';
							}else{
								$a++;
							}
							echo '<img src="http://vereda.server.com:8888/painel/images/icons/jpeg/'.$icons.'.jpg" style="width:30px;max-height:12px; margin:0px 2px 0; float:left" />';
						}
						?>
						</td>
						</tr>
						
					</table>
					</td>
				</tr>
				<tr style="text-align:center">
					<td>
						<h4 style="font-size:45px;font-family:hurmegeometricsans4; margin:0">U</h4>
						<strong style="text-transform: uppercase; font-size:7px; margin:2px 0 0; display: inline-block">Feito no Rio Grande do Sul</strong>
					</td>
				</tr>
			</table>
		</td>
		<?
					$count++;
		}
		}
			
			
			
		
			
			
	 } ?>
	 </tr>
	</table>
</page>
